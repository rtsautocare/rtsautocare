import { useState } from "react";
import { z } from "zod";
import { contact, services } from "./data";

const schema = z.object({
  name: z.string().trim().min(2, "Please enter your name").max(80),
  phone: z
    .string()
    .trim()
    .min(7, "Please enter a contact number")
    .max(20)
    .regex(/^[0-9+\s()-]+$/, "Numbers only, please"),
  reg: z.string().trim().max(12, "That reg looks too long").optional().or(z.literal("")),
  service: z.string().min(1),
  message: z.string().trim().max(800, "Please keep it under 800 characters").optional().or(z.literal("")),
});

type Errors = Partial<Record<keyof z.infer<typeof schema>, string>>;

const inputClass =
  "mt-2 w-full rounded-sm border border-border bg-background px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/60 focus:border-signal focus:outline-none";
const labelClass = "block text-[11px] uppercase tracking-[0.16em] text-muted-foreground";

export function ContactForm() {
  const [errors, setErrors] = useState<Errors>({});
  const [sent, setSent] = useState(false);

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const parsed = schema.safeParse({
      name: String(form.get("name") ?? ""),
      phone: String(form.get("phone") ?? ""),
      reg: String(form.get("reg") ?? ""),
      service: String(form.get("service") ?? ""),
      message: String(form.get("message") ?? ""),
    });

    if (!parsed.success) {
      const next: Errors = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path[0] as keyof Errors;
        if (!next[key]) next[key] = issue.message;
      }
      setErrors(next);
      return;
    }

    setErrors({});
    const d = parsed.data;
    const lines = [
      `Enquiry from ${d.name}`,
      `Phone: ${d.phone}`,
      d.reg ? `Reg: ${d.reg.toUpperCase()}` : null,
      `Service: ${d.service}`,
      d.message ? `Details: ${d.message}` : null,
    ].filter(Boolean);

    window.open(
      `https://wa.me/${contact.whatsappIntl}?text=${encodeURIComponent(lines.join("\n"))}`,
      "_blank",
      "noopener,noreferrer",
    );
    setSent(true);
  }

  return (
    <form onSubmit={handleSubmit} className="mt-8 space-y-4" noValidate>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="block">
          <span className={labelClass}>Name</span>
          <input name="name" type="text" placeholder="Your name" className={inputClass} />
          {errors.name ? <span className="mt-1 block text-xs text-destructive">{errors.name}</span> : null}
        </label>
        <label className="block">
          <span className={labelClass}>Phone</span>
          <input name="phone" type="tel" placeholder="07…" className={inputClass} />
          {errors.phone ? <span className="mt-1 block text-xs text-destructive">{errors.phone}</span> : null}
        </label>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <label className="block">
          <span className={labelClass}>Vehicle reg</span>
          <input name="reg" type="text" placeholder="AB12 CDE" className={`${inputClass} uppercase tracking-wide`} />
          {errors.reg ? <span className="mt-1 block text-xs text-destructive">{errors.reg}</span> : null}
        </label>
        <label className="block">
          <span className={labelClass}>What do you need?</span>
          <select name="service" defaultValue={services[0]!.title} className={inputClass}>
            {services.map((service) => (
              <option key={service.title}>{service.title}</option>
            ))}
          </select>
        </label>
      </div>

      <label className="block">
        <span className={labelClass}>Message</span>
        <textarea
          name="message"
          rows={4}
          placeholder="Tell us what's going on with the car…"
          className={`${inputClass} resize-none`}
        />
        {errors.message ? <span className="mt-1 block text-xs text-destructive">{errors.message}</span> : null}
      </label>

      <button
        type="submit"
        className="w-full rounded-sm bg-signal px-6 py-3 font-display text-sm font-semibold uppercase tracking-[0.14em] text-primary-foreground transition-opacity hover:opacity-90 sm:w-auto"
      >
        Send enquiry
      </button>

      <p className="text-xs text-muted-foreground">
        {sent
          ? "Your details are ready to send in WhatsApp — hit send there and we'll come straight back to you."
          : `Your enquiry opens in WhatsApp to ${contact.whatsapp}. Prefer to talk? Call ${contact.landline}.`}
      </p>
    </form>
  );
}
