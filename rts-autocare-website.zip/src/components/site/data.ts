import heroM4 from "@/assets/hero-m4.jpg.asset.json";
import m4Detail from "@/assets/m4-detail.jpg.asset.json";
import m4Front from "@/assets/m4-front.jpg.asset.json";
import sciroccoRamp from "@/assets/scirocco-ramp.jpg.asset.json";
import sciroccoSign from "@/assets/scirocco-sign.jpg.asset.json";
import audiQ5 from "@/assets/audi-q5.jpg.asset.json";
import golf from "@/assets/golf.jpg.asset.json";
import mercedesC from "@/assets/mercedes-c.jpg.asset.json";
import bmw3 from "@/assets/bmw-3.jpg.asset.json";
import carplay from "@/assets/carplay.jpg.asset.json";
import logo from "@/assets/rts-logo.jpg.asset.json";

export const images = {
  heroM4: heroM4.url,
  m4Detail: m4Detail.url,
  m4Front: m4Front.url,
  sciroccoRamp: sciroccoRamp.url,
  sciroccoSign: sciroccoSign.url,
  audiQ5: audiQ5.url,
  golf: golf.url,
  mercedesC: mercedesC.url,
  bmw3: bmw3.url,
  carplay: carplay.url,
  logo: logo.url,
};

export const openingHours = [
  { day: "Monday – Friday", time: "9:00am – 6:00pm" },
  { day: "Saturday", time: "9:00am – 5:00pm" },
  { day: "Sunday", time: "Closed" },
];

export const contact = {
  whatsapp: "07999 890960",
  whatsappIntl: "447999890960",
  landline: "0116 348 0022",
  landlineTel: "+441163480022",
  address: "Unit 10, Benson Street, Leicester LE5 4HB",
  instagram: "https://www.instagram.com/rtsautocare/",
  mapsQuery: "RTS+Autocare+Unit+10+Benson+Street+Leicester+LE5+4HB",
};

export const services = [
  {
    code: "01",
    title: "Servicing",
    body: "Full and interim servicing to manufacturer schedules — oil, filters, fluids and a written condition check.",
  },
  {
    code: "02",
    title: "Diagnostics",
    body: "Warning lights, intermittent faults and deep electrical fault-finding. We find it before we replace anything.",
  },
  {
    code: "03",
    title: "Repairs",
    body: "Clutch, timing, suspension, brakes and engine work — quoted up front, no surprises on collection.",
  },
  {
    code: "04",
    title: "Remapping",
    body: "Custom performance and economy maps, written safely and matched to your engine and hardware.",
  },
  {
    code: "05",
    title: "Modifications",
    body: "Exhausts, intakes, suspension and styling work, fitted properly and finished to a standard you can show off.",
  },
  {
    code: "06",
    title: "Bodykits — supply & fit",
    body: "Splitters, diffusers, spoilers and full kits sourced, prepped and fitted with the panel gaps done right.",
  },
  {
    code: "07",
    title: "BMW coding",
    body: "Hidden features, retrofits and module coding across the BMW range, done with proper dealer-level tooling.",
  },
  {
    code: "08",
    title: "CarPlay & Android Auto",
    body: "Apple CarPlay and Android Auto retrofitted into factory screens — wireless where your car supports it.",
  },
];

export const reviews = [
  {
    quote:
      "Sufyan was really thorough and helpful with my service. He took the time to explain things clearly and did a really good job on a second hand car I've just bought so I was kept updated and well informed. I'd recommend going here 100% great garage.",
    name: "Rebecca",
    car: "Nissan Pixo",
  },
  {
    quote:
      "Had a great experience getting my service done at RTS. They were very helpful talking me through everything that will be done to my car and even gave me advice about my other car. Top notch service!",
    name: "Verified customer",
    car: "BMW 225e",
  },
  {
    quote:
      "I'm very happy with the work carried out. I was charged a fair price for the services, and Sufyan was extremely helpful and professional throughout. I highly recommend RTS and will definitely return in the future.",
    name: "Verified customer",
    car: "Volkswagen Golf",
  },
];

export const gallery = [
  { src: images.sciroccoRamp, alt: "Volkswagen Scirocco R raised on the two-post ramp inside the RTS Autocare workshop" },
  { src: images.audiQ5, alt: "Audi Q5 TDI quattro parked under the illuminated RTS sign" },
  { src: images.golf, alt: "Volkswagen Golf with RTS Autocare plate in the workshop entrance" },
  { src: images.mercedesC, alt: "Mercedes-Benz C 350 e finished and lit under the red RTS sign" },
  { src: images.m4Detail, alt: "Close-up of a BMW M4 Competition front splitter fitted at RTS Autocare" },
  { src: images.carplay, alt: "Apple CarPlay running on a Mercedes factory screen after a retrofit at RTS Autocare" },
  { src: images.bmw3, alt: "BMW 3 Series with RTS Autocare plate inside the unit" },
  { src: images.sciroccoSign, alt: "Volkswagen Scirocco R beneath the glowing RTS workshop sign" },
];
