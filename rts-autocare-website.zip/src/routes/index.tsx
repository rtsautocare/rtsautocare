import { createFileRoute } from "@tanstack/react-router";
import { ContactForm } from "@/components/site/ContactForm";
import { contact, gallery, images, openingHours, reviews, services } from "@/components/site/data";

const title = "RTS Autocare — Car Servicing, Remapping & BMW Coding in Leicester";
const description =
  "Independent Leicester garage for servicing, diagnostics, repairs, remapping, modifications, bodykits, BMW coding and CarPlay retrofits. Honest quotes, quality workmanship.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: Home,
});

const nav = [
  { href: "#services", label: "Services" },
  { href: "#work", label: "Our work" },
  { href: "#why", label: "Why us" },
  { href: "#reviews", label: "Reviews" },
  { href: "#contact", label: "Contact" },
];

const trust = [
  { title: "Honest", body: "We show you the part, explain the why, and never fit what your car doesn't need." },
  { title: "Affordable", body: "Specialist-level work at independent prices, quoted before a spanner is picked up." },
  { title: "Reliable", body: "Booked slots that hold, clear updates, and cars handed back when we said we would." },
  { title: "Saturdays", body: "Open on Saturdays, so the car fits around your week instead of against it." },
];

function Wordmark({ className = "h-10" }: { className?: string }) {
  return (
    <img
      src={images.logo}
      alt="RTS Autocare logo"
      className={`${className} w-auto rounded-full`}
      width={240}
      height={240}
    />
  );
}

function Home() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b border-border/70 bg-background/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <a href="#top" className="flex items-center gap-3">
            <Wordmark className="h-14" />
            <span className="sr-only">RTS Autocare</span>
          </a>
          <nav className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
            {nav.map((item) => (
              <a key={item.href} href={item.href} className="transition-colors hover:text-foreground">
                {item.label}
              </a>
            ))}
          </nav>
          <a
            href="#contact"
            className="rounded-sm bg-signal px-4 py-2 font-display text-xs font-semibold uppercase tracking-[0.16em] text-primary-foreground"
          >
            Book a slot
          </a>
        </div>
      </header>

      <main id="top">
        {/* HERO */}
        <section className="relative overflow-hidden border-b border-border/70">
          <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-16 lg:grid-cols-[1.05fr_0.95fr] lg:py-24">
            <div className="reveal">
              <p className="eyebrow">Independent garage · Leicester LE5</p>
              <h1 className="mt-5 max-w-[16ch] font-display text-5xl leading-[0.98] font-bold tracking-tight lg:text-6xl">
                Serviced, tuned and finished <span className="text-signal">to spec.</span>
              </h1>
              <p className="mt-6 max-w-[46ch] text-base leading-relaxed text-muted-foreground">
                Servicing, diagnostics and repairs for the cars you rely on — plus remapping, modifications, bodykits,
                BMW coding and CarPlay retrofits for the ones you enjoy.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <a
                  href={`https://wa.me/${contact.whatsappIntl}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-sm bg-signal px-6 py-3 font-display text-sm font-semibold uppercase tracking-[0.14em] text-primary-foreground"
                >
                  WhatsApp us
                </a>
                <a
                  href={`tel:${contact.landlineTel}`}
                  className="rounded-sm border border-border px-6 py-3 font-display text-sm font-semibold uppercase tracking-[0.14em] text-foreground transition-colors hover:border-signal hover:text-signal"
                >
                  {contact.landline}
                </a>
              </div>
              <dl className="mt-10 grid max-w-md grid-cols-3 gap-4">
                {[
                  ["Fixed", "Quotes up front"],
                  ["Sat", "Open Saturdays"],
                  ["LE5", "Benson Street"],
                ].map(([big, small]) => (
                  <div key={small} className="border-t border-border pt-3">
                    <dt className="font-display text-2xl leading-none font-bold text-signal">{big}</dt>
                    <dd className="mt-1.5 text-[11px] uppercase tracking-[0.14em] text-muted-foreground">{small}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="reveal overflow-hidden rounded-sm border border-border">
              <img
                src={images.heroM4}
                alt="BMW M4 Competition lit beneath the orange RTS sign inside the RTS Autocare workshop in Leicester"
                className="aspect-[4/3] w-full object-cover"
                width={1600}
                height={1200}
              />
            </div>
          </div>
        </section>

        {/* SERVICES */}
        <section id="services" className="mx-auto max-w-6xl px-5 py-20">
          <div className="flex flex-wrap items-end justify-between gap-6 border-b border-border pb-6">
            <div>
              <p className="eyebrow">01 / Services</p>
              <h2 className="mt-3 font-display text-3xl font-bold tracking-tight lg:text-4xl">
                Everything the car asks for
              </h2>
            </div>
            <p className="max-w-[36ch] text-sm text-muted-foreground">
              From a routine service to a full build — priced up front and explained plainly.
            </p>
          </div>

          <div className="mt-10 grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-4">
            {services.map((service) => (
              <article
                key={service.title}
                className="group bg-surface p-6 transition-colors hover:bg-surface-2"
              >
                <span className="font-display text-xs tracking-[0.2em] text-signal">{service.code}</span>
                <h3 className="mt-5 font-display text-lg font-semibold">{service.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{service.body}</p>
              </article>
            ))}
          </div>
        </section>

        {/* WORK */}
        <section id="work" className="border-y border-border/70 bg-surface/40">
          <div className="mx-auto max-w-6xl px-5 py-20">
            <p className="eyebrow">02 / Our work</p>
            <h2 className="mt-3 max-w-[24ch] font-display text-3xl font-bold tracking-tight lg:text-4xl">
              Cars that leave the unit right
            </h2>
            <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {gallery.map((item) => (
                <figure key={item.src} className="overflow-hidden rounded-sm border border-border">
                  <img
                    src={item.src}
                    alt={item.alt}
                    loading="lazy"
                    className="aspect-square w-full object-cover transition-transform duration-500 hover:scale-[1.03]"
                    width={1200}
                    height={1200}
                  />
                </figure>
              ))}
            </div>
          </div>
        </section>

        {/* WHY */}
        <section id="why" className="mx-auto max-w-6xl px-5 py-20">
          <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
            <div>
              <p className="eyebrow">03 / Why RTS</p>
              <h2 className="mt-3 max-w-[22ch] font-display text-3xl font-bold tracking-tight lg:text-4xl">
                The independent that behaves like the main dealer
              </h2>
              <p className="mt-5 max-w-[40ch] text-base leading-relaxed text-muted-foreground">
                Local, answerable and accountable — you deal with the same people who put the car back on the road.
              </p>
              <div className="mt-8 overflow-hidden rounded-sm border border-border">
                <img
                  src={images.m4Front}
                  alt="Front three-quarter view of a black BMW M4 Competition after work at RTS Autocare"
                  loading="lazy"
                  className="aspect-[4/3] w-full object-cover"
                  width={1600}
                  height={1200}
                />
              </div>
            </div>
            <div className="grid gap-px self-start bg-border sm:grid-cols-2">
              {trust.map((item) => (
                <div key={item.title} className="bg-surface p-6">
                  <p className="font-display text-2xl leading-none font-bold">{item.title}</p>
                  <p className="mt-3 max-w-[30ch] text-sm leading-relaxed text-muted-foreground">{item.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* REVIEWS */}
        <section id="reviews" className="border-y border-border/70 bg-surface/40">
          <div className="mx-auto max-w-6xl px-5 py-20">
            <p className="eyebrow">04 / Reviews</p>
            <h2 className="mt-3 font-display text-3xl font-bold tracking-tight lg:text-4xl">Word from the forecourt</h2>
            <div className="mt-10 grid gap-px bg-border md:grid-cols-3">
              {reviews.map((review) => (
                <figure key={review.quote} className="bg-surface p-6">
                  <div className="font-display text-signal">★★★★★</div>
                  <blockquote className="mt-4 text-[15px] leading-relaxed text-foreground">“{review.quote}”</blockquote>
                  <figcaption className="mt-4 text-xs uppercase tracking-[0.16em] text-muted-foreground">
                    {review.name} · {review.car}
                  </figcaption>
                </figure>
              ))}
            </div>
          </div>
        </section>

        {/* CONTACT */}
        <section id="contact" className="mx-auto max-w-6xl px-5 py-20">
          <div className="grid gap-10 lg:grid-cols-2">
            <div>
              <p className="eyebrow">05 / Book in</p>
              <h2 className="mt-3 max-w-[22ch] font-display text-3xl font-bold tracking-tight lg:text-4xl">
                Send your reg and we'll come back to you
              </h2>
              <p className="mt-4 max-w-[42ch] text-base leading-relaxed text-muted-foreground">
                Tell us the car and the job. We'll confirm a slot and a price — no obligation.
              </p>
              <ContactForm />
            </div>

            <div className="space-y-4">
              <div className="overflow-hidden rounded-sm border border-border">
                <iframe
                  title="Map showing RTS Autocare on Benson Street, Leicester"
                  src={`https://www.google.com/maps?q=${contact.mapsQuery}&output=embed`}
                  loading="lazy"
                  className="aspect-[4/3] w-full"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
              <div className="rounded-sm border border-border bg-surface p-6">
                <p className="eyebrow">Find us</p>
                <p className="mt-2 font-display text-lg font-semibold">RTS Autocare Ltd</p>
                <p className="mt-1 text-sm text-muted-foreground">{contact.address}</p>
                <div className="mt-5 grid gap-4 border-t border-border pt-5 text-sm sm:grid-cols-2">
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">WhatsApp</p>
                    <a
                      href={`https://wa.me/${contact.whatsappIntl}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-1 block text-foreground hover:text-signal"
                    >
                      {contact.whatsapp}
                    </a>
                  </div>
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">Landline</p>
                    <a href={`tel:${contact.landlineTel}`} className="mt-1 block text-foreground hover:text-signal">
                      {contact.landline}
                    </a>
                  </div>
                </div>
                <div className="mt-5 border-t border-border pt-5">
                  <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">Opening hours</p>
                  <dl className="mt-3 space-y-2 text-sm">
                    {openingHours.map((slot) => (
                      <div key={slot.day} className="flex items-baseline justify-between gap-4">
                        <dt className="text-muted-foreground">{slot.day}</dt>
                        <dd className="font-display font-semibold text-foreground">{slot.time}</dd>
                      </div>
                    ))}
                  </dl>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border/70">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-5 py-10 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <Wordmark className="h-12" />
            <span className="font-display text-xs uppercase tracking-[0.28em]">Ltd</span>
          </div>
          <p>{contact.address}</p>
          <a href={contact.instagram} target="_blank" rel="noopener noreferrer" className="hover:text-signal">
            Instagram
          </a>
        </div>
      </footer>
    </div>
  );
}
